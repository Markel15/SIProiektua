package pokemon;

public class PokemonSua extends Pokemon {
	public PokemonSua(int pId,int pJokId) {
		super(pId,pJokId);
		this.setMota("Sua");
	}
}
