package pokemon;

public class PokemonBelarra extends Pokemon {
	public PokemonBelarra(int pId,int pJokId) {
		super(pId,pJokId);
		this.setMota("Belarra");
	}
}
