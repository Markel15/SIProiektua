package pokemon;

public class PokemonUra extends Pokemon{
	public PokemonUra(int pId,int pJokId) {
		super(pId,pJokId);
		this.setMota("Ur");
	}
}
