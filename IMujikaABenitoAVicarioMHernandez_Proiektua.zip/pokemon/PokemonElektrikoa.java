package pokemon;

public class PokemonElektrikoa extends Pokemon {
	public PokemonElektrikoa(int pId,int pJokId) {
		super(pId,pJokId);
		this.setMota("Elektrikoa");
	}
}
