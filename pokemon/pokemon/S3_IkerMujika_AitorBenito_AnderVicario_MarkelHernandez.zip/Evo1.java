package pokemon;

public class Evo1 implements Egoera {
	public Evo1() {
		
	}

	@Override
	public int egoerarenAraberakoErasoa() {
		// TODO Auto-generated method stub
		return 5;
	}

	@Override
	public int egoerarenAraberakoDefentsa() {
		// TODO Auto-generated method stub
		return 3;
	}
	@Override
	public int evoKop() {
		return 1;
	}

}
