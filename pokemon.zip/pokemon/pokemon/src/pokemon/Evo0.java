package pokemon;

public class Evo0 implements Egoera {
	public Evo0() {
		
	}

	@Override
	public int egoerarenAraberakoErasoa() {
		return 0;
	}

	@Override
	public int egoerarenAraberakoDefentsa() {
		return 0;
	}
	@Override
	public int evoKop() {
		return 0;
	}
}
