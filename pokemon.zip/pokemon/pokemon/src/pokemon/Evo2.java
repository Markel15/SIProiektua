package pokemon;

public class Evo2 implements Egoera{
	public Evo2() {
		
	}

	@Override
	public int egoerarenAraberakoErasoa() {
		// TODO Auto-generated method stub
		return 7;
	}

	@Override
	public int egoerarenAraberakoDefentsa() {
		// TODO Auto-generated method stub
		return 5;
	}
	@Override
	public int evoKop() {
		return 2;
	}
}
