package pokemon;

public class Euforia implements Egoera {
	public Euforia() {
		
	}

	@Override
	public int egoerarenAraberakoErasoa() {
		return 100;
	}

	@Override
	public int egoerarenAraberakoDefentsa() {
		return 100;
	}

	@Override
	public int evoKop() {
		return 3;
	}

}
