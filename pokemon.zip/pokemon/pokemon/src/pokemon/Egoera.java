package pokemon;

public interface Egoera {
	int egoerarenAraberakoErasoa();
	
	int egoerarenAraberakoDefentsa();
	
	int evoKop();

}
